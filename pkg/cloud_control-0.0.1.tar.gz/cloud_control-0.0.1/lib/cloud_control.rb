class CloudControl
  def self.test
    puts "BLAH!"
  end
end